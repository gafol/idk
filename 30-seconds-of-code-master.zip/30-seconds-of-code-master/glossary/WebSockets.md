### WebSockets

WebSockets is a protocol that allows for a persistent client-server TCP connection.
The WebSocket protocol uses lower overheads, facilitating real-time data transfer between client and server.
