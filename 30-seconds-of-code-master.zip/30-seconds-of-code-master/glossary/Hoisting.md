### Hoisting

Hoisting is JavaScript's default behavior of adding declarations to memory during the compile phase.
Hoisting allows for JavaScript variables to be used before the line they were declared on.
