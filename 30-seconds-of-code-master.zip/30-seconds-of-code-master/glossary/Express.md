### Express

Express is a backend framework, that provides a layer of fundamental web application features for Node.js.
Some of its key features are routing, middleware, template engines and error handling.
