### Continuous Deployment

Continuous Deployment follows the testing that happens during Continuous Integration and pushes changes to a staging or production system. 
Continuous Deployment ensures that a version of the codebase is accessible at all times.