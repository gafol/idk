### String

Strings are one of the primitive data types in JavaScript.
They are sequences of characters and are used to represent text.
