### Constant

A constant is a value, associated with an identifier.
The value of a constant can be accessed using the identifier and cannot be altered during execution.
