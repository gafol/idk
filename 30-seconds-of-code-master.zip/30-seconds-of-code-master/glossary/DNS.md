### DNS

A DNS (Domain Name System) translates domain names to the IP addresses needed to find a particular computer service on a network.
