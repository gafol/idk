### Element

A JavaScript representation of a DOM element commonly returned by `document.querySelector()` and `document.createElement()`. 
They are used when creating content with JavaScript for display in the DOM that needs to be programatically generated.
