### Web Components

Web Components are a set of web platform APIs that allow you to create new custom, reusable, encapsulated HTML tags to use on web pages and apps.
Building custom components using these standards means that you can use them across modern browsers regardless of any JavaScript library or framework.
