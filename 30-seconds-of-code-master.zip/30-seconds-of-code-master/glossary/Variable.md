### Variable

A variable is a storage location, associated with an identifier and containing a value.
The value of a variable can be referred using the identifier and can be altered during execution.
