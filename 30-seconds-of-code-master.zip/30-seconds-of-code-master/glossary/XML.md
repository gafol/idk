### XML

XML stands for eXtensible Markup Language and is a generic markup language specified by the W3C. 
XML documents are plaintext documents structured with user-defined tags, surrounded by `<>` and optionally extended with attributes.
