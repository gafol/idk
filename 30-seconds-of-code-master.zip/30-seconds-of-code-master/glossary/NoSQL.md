### NoSQL

NoSQL databases provide a mechanism to create, update, retrieve and calculate data that is stored in models that are non-tabular.