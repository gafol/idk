### SVG

SVG stands for Scalable Vector Graphics and is a 2D vector image format based on an XML syntax.
SVG images can scale infinitely and can utilize clipping, masking, filters, animations etc.
