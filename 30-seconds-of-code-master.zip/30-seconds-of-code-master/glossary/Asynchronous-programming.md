### Asynchronous programming

Asynchronous programming is a way to allow multiple events to trigger code without waiting for each other.
The main benefits of asynchronous programming are improved application performance and responsiveness.
