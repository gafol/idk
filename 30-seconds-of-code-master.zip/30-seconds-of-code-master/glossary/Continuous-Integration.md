### Continuous Integration

Continuous Integration (CI) is the practice of testing each change done to a codebase automatically and as early as possible.
Two popular CI systems that integrate with GitHub are Travis CI and Circle CI.