### CSV

CSV stands for Comma-Separated Values and is a storage format for tabular data.
CSV documents are plaintext documents where each line represents a table row, with table columns separated by commas or some other delimiter (e.g. semicolons).
The first line of a CSV document sometimes consists of the table column headings for the data to follow.
