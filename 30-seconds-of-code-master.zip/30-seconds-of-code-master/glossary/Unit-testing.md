### Unit testing

Unit testing is a type of software testing, used to test individual units/components of a software.
The purpose of unit tests are to validate that each individual unit/component performs as designed.
