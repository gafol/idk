### Functor

A Functor is a data type common in functional programming that implements a `map` method. 
The `map` method takes a function and applies it to the data in the Functor, returning a new instance of the Functor with the result.
JavaScript `Array`s are an example of the Functor data type.
